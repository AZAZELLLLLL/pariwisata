from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, session
import mysql.connector
from datetime import datetime
import os
from decimal import Decimal

app = Flask(__name__)
app.secret_key = 'eltravel_secret_key_2024'

# ════════════════════════════════════════
# DATABASE CONNECTION
# ════════════════════════════════════════

def get_db():
    """Create database connection to pariwisataDb"""
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='pariwisataDb'
    )

# ════════════════════════════════════════
# HOMEPAGE & DESTINASI ROUTES
# ════════════════════════════════════════

@app.route('/')
def index():
    """Homepage - show wisata cards"""
    wisata = []
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        cur.execute("SELECT * FROM wisata LIMIT 8")
        wisata = cur.fetchall()
        cur.close()
        db.close()
    except Exception as e:
        print(f"Index error: {e}")
        wisata = []
    return render_template('index.html', wisata=wisata)

@app.route('/destinasi')
def destinasi():
    """Destinasi page with filters"""
    wisata = []
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        
        # Get filter parameters
        tipe = request.args.get('tipe', '')
        kategori = request.args.get('kategori', '')
        
        # Build query
        query = "SELECT * FROM wisata"
        conditions = []
        
        if tipe in ['lokal', 'internasional']:
            conditions.append(f"tipe = '{tipe}'")
        
        if kategori:
            # Sanitize kategori
            kategori_safe = kategori.replace("'", "''")
            conditions.append(f"kategori = '{kategori_safe}'")
        
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        
        query += " ORDER BY id"
        
        cur.execute(query)
        wisata = cur.fetchall()
        cur.close()
        db.close()
    except Exception as e:
        print(f"Destinasi error: {e}")
        wisata = []
    
    return render_template('destinasi.html', wisata=wisata)

@app.route('/wisata/<int:id>')
def detail_wisata(id):
    """Detail wisata page"""
    wisata = None
    paket = []
    reviews = []
    
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        
        # Get wisata data
        cur.execute("SELECT * FROM wisata WHERE id = %s", (id,))
        wisata = cur.fetchone()
        
        # Get paket
        if wisata:
            cur.execute("SELECT * FROM tipe_paket WHERE wisata_id = %s", (id,))
            paket = cur.fetchall()
            
            # Get reviews
            cur.execute("""
                SELECT rr.* FROM rating_review rr
                JOIN wisata w ON rr.destinasi_id = w.id
                WHERE w.id = %s AND rr.status_review = 'published'
                ORDER BY rr.tanggal_publish DESC
                LIMIT 5
            """, (id,))
            reviews = cur.fetchall()
        
        cur.close()
        db.close()
    except Exception as e:
        print(f"Detail wisata error: {e}")
    
    return render_template('detail.html', wisata=wisata, paket=paket, reviews=reviews)

# ════════════════════════════════════════
# BOOKING ROUTES
# ════════════════════════════════════════

@app.route('/pesan/<int:paket_id>', methods=['GET', 'POST'])
def pesan(paket_id):
    """Booking form"""
    paket = None
    wisata_id = None
    
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        cur.execute("""
            SELECT tp.*, w.nama as wisata_nama, w.lokasi, w.foto, w.id as wisata_id
            FROM tipe_paket tp
            JOIN wisata w ON tp.wisata_id = w.id
            WHERE tp.id = %s
        """, (paket_id,))
        paket = cur.fetchone()
        
        if paket:
            wisata_id = paket['wisata_id']
        
        cur.close()
        db.close()
    except Exception as e:
        print(f"Pesan GET error: {e}")

    if request.method == 'POST' and paket:
        try:
            db = get_db()
            cur = db.cursor()
            
            nama_pemesan = request.form.get('nama_pemesan', '').strip()
            email = request.form.get('email', '').strip()
            telepon = request.form.get('telepon', '').strip()
            tanggal_pergi = request.form.get('tanggal_pergi', '')
            jumlah_orang = int(request.form.get('jumlah_orang', 1))
            catatan = request.form.get('catatan', '').strip()
            
            # Validate
            if not all([nama_pemesan, email, telepon, tanggal_pergi]):
                flash('Semua field harus diisi!', 'error')
                cur.close()
                db.close()
                return render_template('pesan.html', paket=paket)
            
            total_harga = int(paket['harga']) * jumlah_orang
            
            # Insert booking
            cur.execute("""
                INSERT INTO pemesanan
                  (paket_id, nama_pemesan, email, telepon, tanggal_pergi,
                   jumlah_orang, total_harga, tanggal_pesan, status, catatan)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'pending',%s)
            """, (paket_id, nama_pemesan, email, telepon, tanggal_pergi,
                  jumlah_orang, total_harga, datetime.now(), catatan))
            
            db.commit()
            pemesanan_id = cur.lastrowid
            
            cur.close()
            db.close()
            
            flash('Pemesanan berhasil! Lanjut ke pembayaran.', 'success')
            return redirect(url_for('pembayaran', pemesanan_id=pemesanan_id))
        
        except Exception as e:
            print(f"Pesan POST error: {e}")
            flash(f'Terjadi kesalahan: {str(e)}', 'error')

    return render_template('pesan.html', paket=paket)

# ════════════════════════════════════════
# PAYMENT ROUTES (NEW!)
# ════════════════════════════════════════

@app.route('/pembayaran/<int:pemesanan_id>', methods=['GET', 'POST'])
def pembayaran(pemesanan_id):
    """Payment page"""
    pemesanan = None
    paket = None
    
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        
        # Get booking data
        cur.execute("""
            SELECT p.*, tp.nama_paket, tp.harga, w.nama as wisata_nama, w.foto
            FROM pemesanan p
            JOIN tipe_paket tp ON p.paket_id = tp.id
            JOIN wisata w ON tp.wisata_id = w.id
            WHERE p.id = %s
        """, (pemesanan_id,))
        pemesanan = cur.fetchone()
        
        # Check if payment already exist
        if pemesanan:
            cur.execute("SELECT * FROM pembayaran WHERE pemesanan_id = %s", (pemesanan_id,))
            existing_payment = cur.fetchone()
            
            if existing_payment and existing_payment['status_pembayaran'] == 'berhasil':
                flash('Pembayaran sudah berhasil!', 'info')
                cur.close()
                db.close()
                return redirect(url_for('konfirmasi_pembayaran', pemesanan_id=pemesanan_id))
        
        cur.close()
        db.close()
    except Exception as e:
        print(f"Pembayaran GET error: {e}")

    if request.method == 'POST' and pemesanan:
        try:
            db = get_db()
            cur = db.cursor()
            
            metode_pembayaran = request.form.get('metode_pembayaran', 'transfer')
            keterangan = request.form.get('keterangan', '').strip()
            
            # Validate
            if metode_pembayaran not in ['transfer', 'kartu_kredit', 'qr_code', 'cicilan']:
                flash('Metode pembayaran tidak valid!', 'error')
                cur.close()
                db.close()
                return render_template('pembayaran.html', pemesanan=pemesanan)
            
            # Insert payment record
            cur.execute("""
                INSERT INTO pembayaran
                  (pemesanan_id, metode_pembayaran, status_pembayaran,
                   tanggal_pembayaran, jumlah_dibayar, keterangan, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (pemesanan_id, metode_pembayaran, 'menunggu_verifikasi',
                  datetime.now(), pemesanan['total_harga'], keterangan, datetime.now()))
            
            db.commit()
            pembayaran_id = cur.lastrowid
            
            # Update pemesanan status
            cur.execute("""
                UPDATE pemesanan SET status = 'confirmed' WHERE id = %s
            """, (pemesanan_id,))
            db.commit()
            
            cur.close()
            db.close()
            
            flash('Pembayaran terima! Tim kami akan verifikasi segera.', 'success')
            return redirect(url_for('konfirmasi_pembayaran', pemesanan_id=pemesanan_id))
        
        except Exception as e:
            print(f"Pembayaran POST error: {e}")
            flash(f'Terjadi kesalahan: {str(e)}', 'error')

    return render_template('pembayaran.html', pemesanan=pemesanan)

@app.route('/konfirmasi_pembayaran/<int:pemesanan_id>')
def konfirmasi_pembayaran(pemesanan_id):
    """Payment confirmation page"""
    pemesanan = None
    pembayaran = None
    
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        
        # Get booking
        cur.execute("""
            SELECT p.*, tp.nama_paket, w.nama as wisata_nama
            FROM pemesanan p
            JOIN tipe_paket tp ON p.paket_id = tp.id
            JOIN wisata w ON tp.wisata_id = w.id
            WHERE p.id = %s
        """, (pemesanan_id,))
        pemesanan = cur.fetchone()
        
        # Get payment
        if pemesanan:
            cur.execute("SELECT * FROM pembayaran WHERE pemesanan_id = %s", (pemesanan_id,))
            pembayaran = cur.fetchone()
        
        cur.close()
        db.close()
    except Exception as e:
        print(f"Konfirmasi error: {e}")

    return render_template('konfirmasi_pembayaran.html', pemesanan=pemesanan, pembayaran=pembayaran)

# ════════════════════════════════════════
# RATING/REVIEW ROUTES (NEW!)
# ════════════════════════════════════════

@app.route('/review/<int:pemesanan_id>', methods=['GET', 'POST'])
def review(pemesanan_id):
    """Rating and review page"""
    pemesanan = None
    existing_review = None
    
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        
        # Get booking info
        cur.execute("""
            SELECT p.*, tp.wisata_id, w.nama as wisata_nama, w.foto
            FROM pemesanan p
            JOIN tipe_paket tp ON p.paket_id = tp.id
            JOIN wisata w ON tp.wisata_id = w.id
            WHERE p.id = %s
        """, (pemesanan_id,))
        pemesanan = cur.fetchone()
        
        # Check if already reviewed
        if pemesanan:
            cur.execute("""
                SELECT * FROM rating_review WHERE pemesanan_id = %s
            """, (pemesanan_id,))
            existing_review = cur.fetchone()
        
        cur.close()
        db.close()
    except Exception as e:
        print(f"Review GET error: {e}")

    if request.method == 'POST' and pemesanan:
        try:
            db = get_db()
            cur = db.cursor()
            
            nama_pengguna = pemesanan['nama_pemesan']
            email_pengguna = pemesanan['email']
            destinasi_id = pemesanan['wisata_id']
            
            rating_destinasi = float(request.form.get('rating_destinasi', 5.0))
            rating_pelayanan = float(request.form.get('rating_pelayanan', 5.0))
            rating_keseluruhan = float(request.form.get('rating_keseluruhan', 5.0))
            
            judul_review = request.form.get('judul_review', '').strip()
            isi_review = request.form.get('isi_review', '').strip()
            
            # Validate ratings (1-5)
            for rating in [rating_destinasi, rating_pelayanan, rating_keseluruhan]:
                if not (1.0 <= rating <= 5.0):
                    flash('Rating harus antara 1 dan 5!', 'error')
                    cur.close()
                    db.close()
                    return render_template('review.html', pemesanan=pemesanan)
            
            # Check if update or insert
            if existing_review:
                # Update
                cur.execute("""
                    UPDATE rating_review SET
                        rating_destinasi = %s,
                        rating_pelayanan = %s,
                        rating_keseluruhan = %s,
                        judul_review = %s,
                        isi_review = %s,
                        tanggal_review = %s
                    WHERE pemesanan_id = %s
                """, (rating_destinasi, rating_pelayanan, rating_keseluruhan,
                      judul_review, isi_review, datetime.now(), pemesanan_id))
                flash('Rating diperbarui!', 'success')
            else:
                # Insert
                cur.execute("""
                    INSERT INTO rating_review
                      (pemesanan_id, destinasi_id, nama_pengguna, email_pengguna,
                       rating_destinasi, rating_pelayanan, rating_keseluruhan,
                       judul_review, isi_review, status_review, tanggal_review)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending', %s)
                """, (pemesanan_id, destinasi_id, nama_pengguna, email_pengguna,
                      rating_destinasi, rating_pelayanan, rating_keseluruhan,
                      judul_review, isi_review, datetime.now()))
                flash('Terima kasih atas rating Anda! Review akan ditampilkan setelah verifikasi.', 'success')
            
            db.commit()
            cur.close()
            db.close()
            
            return redirect(url_for('riwayat'))
        
        except Exception as e:
            print(f"Review POST error: {e}")
            flash(f'Terjadi kesalahan: {str(e)}', 'error')

    return render_template('review.html', pemesanan=pemesanan, existing_review=existing_review)

# ════════════════════════════════════════
# OTHER ROUTES
# ════════════════════════════════════════

@app.route('/riwayat')
def riwayat():
    """Order history page"""
    riwayat_data = []
    total = {}
    
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        
        # Get all bookings
        cur.execute("""
            SELECT p.*, tp.nama_paket, tp.harga, w.nama as wisata_nama, w.foto
            FROM pemesanan p
            JOIN tipe_paket tp ON p.paket_id = tp.id
            JOIN wisata w ON tp.wisata_id = w.id
            ORDER BY p.tanggal_pesan DESC
        """)
        riwayat_data = cur.fetchall()
        
        # Get total value
        cur.execute("""
            SELECT SUM(total_harga) as total FROM pemesanan 
            WHERE status != 'cancelled'
        """)
        total = cur.fetchone() or {'total': 0}
        
        cur.close()
        db.close()
    except Exception as e:
        print(f"Riwayat error: {e}")

    return render_template('riwayat.html', riwayat=riwayat_data, total=total)

@app.route('/kontak')
def kontak():
    """Contact page"""
    return render_template('kontak.html')

@app.route('/tentang')
def tentang():
    """About page"""
    return render_template('tentang.html')

# ════════════════════════════════════════
# API ENDPOINTS (for AJAX)
# ════════════════════════════════════════

@app.route('/api/destinasi/<int:id>')
def api_destinasi(id):
    """Get destinasi details via API"""
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        cur.execute("SELECT * FROM wisata WHERE id = %s", (id,))
        destinasi = cur.fetchone()
        cur.close()
        db.close()
        
        if destinasi:
            return jsonify(destinasi)
        else:
            return jsonify({'error': 'Not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/paket/<int:wisata_id>')
def api_paket(wisata_id):
    """Get paket by wisata_id via API"""
    try:
        db = get_db()
        cur = db.cursor(dictionary=True)
        cur.execute("SELECT * FROM tipe_paket WHERE wisata_id = %s", (wisata_id,))
        paket = cur.fetchall()
        cur.close()
        db.close()
        
        return jsonify(paket)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ════════════════════════════════════════
# ERROR HANDLERS
# ════════════════════════════════════════

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(error):
    return render_template('500.html'), 500

# ════════════════════════════════════════
# RUN APP
# ════════════════════════════════════════

if __name__ == '__main__':
    app.run(debug=True, port=5000)
